-- UHA Component Uninstall - Drop all tables

DROP TABLE IF EXISTS `#__uha_proof_logs`;
DROP TABLE IF EXISTS `#__uha_usage_cache`;
DROP TABLE IF EXISTS `#__uha_user_tokens`;
DROP TABLE IF EXISTS `#__uha_docs`;
DROP TABLE IF EXISTS `#__uha_config`;
